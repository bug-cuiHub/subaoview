# subaoview

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

### 特别注意
```
Echarts的渲染需要修改npm install包中的vue-echarts
将ECharts.vue中的echarts/lib/echarts换为echarts