<template>
  <div class="content-container"><p>this is error, Please release the information first!</p></div>
</template>

<script>
export default {
  name: "error",
  data: function() {
    return {};
  }
};
</script>

<style>
</style>